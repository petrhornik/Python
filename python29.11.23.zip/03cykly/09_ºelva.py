import turtle

turtle.shape("turtle") # volám funkci (tvar) z knihocny turtle
turtle.forward(200)    # maluje čáru o délce 200
turtle.left(90)        # rotaci o stupne směrem doleva
turtle.forward(200)
turtle.left(90)
turtle.forward(200)
turtle.left(90)
turtle.forward(200)
turtle.exitonclick()   # čeká na kliknutí a poté zavře okno
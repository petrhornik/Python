retezec = input("Zadej řetězec: ")
pocet = 0
for znak in retezec:
    pocet = pocet + 1
    print("Délka řetězce =", pocet)

# Počítá délku řetězce (počet znaků).
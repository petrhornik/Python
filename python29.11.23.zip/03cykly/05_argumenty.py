print(1, "dvě", False) #první řádek ukazuje standartní nastavení printu
print(1, end=" ") # jak nastavit, aby místo odřádkování vypsal mezeru na konci
print(2, 3, 4, sep=" , ") # nastavení vypsání čárky mezi argumenty namísto mezery

# sep [sep=] - určuje, co se vypíše mezi jednotlivými argumenty (místo mezery)
# end [end=] - určuje, co se vypíše na konci místo pokračování na nový řádek
# 5x vypíšeme stejný text
print("python")
print("python")
print("python")
print("python")
print("python")

# místo toho popužijeme novou konstrukci cyklus for
for i in 1,2,3,4,5:
    print("python")

# další program počítá druhou mocninuv některých zadaných prvočísel:

for x in 5, 7, 11, 13, 23:
    x2 = x **2
    print("druhá mocnina", x, "je", x2)
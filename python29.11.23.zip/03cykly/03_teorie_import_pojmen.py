Import a pojmenování

    - Při importování je potřeba si dávat pozor na pojmenování souborů.
    - Program/soubor a importovaná knihonva nesmí mít stejný název.
    - Když importuju math, tak se program nesmí jmenovat math.py.
            - program by se snažil naimportovat sin z math.py místo z knihovny

Volání funkcí
    - voláme jménem
    -jména jako u proměnných - jezná se o takovou proměnnou jen je v ní, místo čísla nebo řetězce, funkce.
    - za jménem funkce jsou závorky - v nich je argument(vstup) fce.
    - to je informace, se kterou bude naše funkce pracovat viz:02_sinus.py
    - např: sin() z argumentu vypočte sinus
    - volání fce je výraz a výsledná, neboli návratová hodnota se dá přiřadit do proměnné

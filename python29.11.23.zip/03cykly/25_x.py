# moje řešení

for i in range(0, 5):
    print("X " * 5)



print("\n")

# řešení z tabule:

for i in range(5):
    for i in range(5):
        print("X", end=" ")
    print()
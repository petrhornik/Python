x = int(input("Zadej počet: "))
for i in range(1, x + 1):
    print("X " * i)
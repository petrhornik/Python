for n in range(5):      #posloupnost čísel od 0 pro menší než 5
    print(n)

for n in range(5, 9):      # posloupnost čísel od 5 pro menší než 9
    print(n)

print()

print(range(7, 100, 11))
range(7, 100, 11)
#zavoláním print(range(7, 100, 11)) se nedozvíme nic užitečné o vygenerované posloupnosti
#Pro kontrolu hodnot vygenerovabných pomocí range() musím zatím použít .....
# pojmenované argumenty
# Některé funce umí pracovat i s pojmenovanými argumenty.
# Píšou se podobně jako přiřazení do proměnné, s rovnítkem, ale uvnitř závorek.
# Třeba funkce print normálně ukončí výpis novým řádkem, ale pomocí argumentu end [end=] se dá vypsat i něco jiného.

print("1 + 2", end=" ")
print("=", end=" ")
print(1 + 2, end="!")
print()
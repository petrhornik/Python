from math import sin

# 1. způsob

x = sin(1)  # (v radiánech)
print(x)

# 2. způsob - totožný s 1.

import math
x = math.sin(1)
print(x)
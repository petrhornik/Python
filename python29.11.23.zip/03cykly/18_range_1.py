for n in range (0, 100):
    print(n, end=", ")

# v následujícím příkazu vypíšeme 100 hodnot
# do jednoho dlouhého řádku a čísla přitom oddělujeme čárkami s mezerou
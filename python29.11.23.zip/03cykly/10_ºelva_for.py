import turtle

for j in range(4):
    turtle.left(90)
    turtle.forward(200)

turtle.exitonclick()
import math
help(math) #nápoměda se dá zobrazit u každého příkazu či knihovny
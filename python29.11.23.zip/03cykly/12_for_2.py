# Podobný výpis, jako v minulém příkladu, dostaneme i takto:
for i in 1,1,1,1,1:
    print("ahoj")
    print("******")

for i in 1,1,1,1,1:
    print("ahoj")
print("*********")  # když neodTABneme
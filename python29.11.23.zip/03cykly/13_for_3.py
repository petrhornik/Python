# v těle cyklu můžeme použít i proměnnou cyklu, jejíž hodnota se při každém průchodu cyklem automaticky mění.
# V následujícím příkladu je proměnnou cyklu prom:

for prom in 1, 2, 3, 4, 5:
    print(prom, end=" ")

# po spuštění programu se postupně vypíší všechny nabyté hodnoty
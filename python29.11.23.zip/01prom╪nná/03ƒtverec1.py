print('Obvod čtverce se stranou 356 cm je', 4 * 356, 'cm')
print('Obsah čtverce se strannou 356 cm je', 356 * 356, 'cm2')
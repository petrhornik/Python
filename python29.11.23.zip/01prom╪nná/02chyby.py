print(1) #1 Když se do závorky nedá "" python bude nahlížet na obsah závorky jako na číslo
print(1, 2, 3) #1.1 Čísla jsou oddělena čárkami!!!
print(1 + 1) #2 Bez "" viz #1 tak python uvedená čísla spočítá
print("3 * 8") #3 Kvůli "" python na obsah (příklad) nahlíží jako na TEXT!!!!
print(10 - 2.2)
print(3 + (4 + 6) * 8 / 2 - 1)
print('Petr ' * 80) #4 80x vypíše Petr s mezerou
print("Ahoj" + " " + "T2B!") #5 součet řetězců (sčítá text [dává to text {a mezery} za sebe])
print("Součet čisel 3 a 8 je", 3 + 8) #6 Díky čárce může v jedné print() závorce být více příkazů!!!
print (Máma má mísu') #7 chyba!!!
print("V míse je maso.")

#7 Mezi "" a '' není rozdíl (zatim).
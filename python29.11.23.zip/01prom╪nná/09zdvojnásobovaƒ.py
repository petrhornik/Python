print("\nZdvojnásobovač čísel. \n") # \n vynechává řádky (\ se píše altgr + q)

cislo = int(input("Zadej číslo: "))
vysledek = cislo * 2
print("Dvojnásobek čísla", cislo, "je", vysledek)

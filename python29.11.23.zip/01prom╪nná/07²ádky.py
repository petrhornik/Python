print("Já jsem první řádka.")
print("A já druhá.")


print("Já jsem první řádka.", "A já druhá.") # možnosti spojení/řešení
print("Já jsem první řádka." + "A já druhá.")
print("Já jsem první řádka." + " " + "A já druhá.")
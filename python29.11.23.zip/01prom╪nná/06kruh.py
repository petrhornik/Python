poloměr = int(input('Zadej poloměr v centimetrech'))
pi = 3.14 # Lze i zadat manuálně pi = float(input('Zadej pi'))

print('Obvod kruhu s poloměrem', poloměr, 'cm je', 2 * pi * poloměr, 'cm')
print('Obsah kruhu s poloměrem', poloměr, 'cm je', pi * poloměr * poloměr, 'cm2')

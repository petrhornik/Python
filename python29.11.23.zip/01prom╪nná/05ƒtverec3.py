# Program na výpočet obvodu a obsahu čtverce:

strana = int(input('Zadej stranu čtverce v centimetrech')) # čeká na vstup od uživatele

print('Obvod čtverce se stranou', strana, 'cm je', 4 * strana, 'cm')
print('Obsah čtverce se strannou', strana, 'cm je', strana * strana, 'cm2')

# strana = float(input('')) - chceme-li načíst desetinné číslo
# strana = int(input('')) - chceme-li načíst celé číslo
# strana = input('') - chceme-li načíst text
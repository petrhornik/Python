strana = 50 # toto je proměnná

print('Obvod čtverce se stranou', strana, 'cm je', 4 * strana, 'cm')
print('Obsah čtverce se strannou', strana, 'cm je', strana * strana, 'cm2')

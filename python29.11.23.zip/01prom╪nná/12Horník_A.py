a = input("Zadej jakýkoli znak: \n")
b = int(input("Kolikrát to mám zopakovat? \n"))

print((a + " ") * b, "\n")
print("Hotovo, zavírám program.")
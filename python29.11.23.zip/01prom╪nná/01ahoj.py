# První program Ahoj.

print("Ahoj")

# První řádek je komentář. Komentář začíná # a Python dále ignoruje co je za ním (na řádku).
# Na další řádce je funkce print(). Tato funkce zobrazí řetězec nebo číslo v konzoli.
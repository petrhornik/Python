cislo = int(input("Zadej celé kladné číslo: "))

if (cislo >=0):
    a = cislo ** 2 # ** 2 znamená na 2 (mocnina)
    print(a)
else:
    print("Toto není kladné číslo!")
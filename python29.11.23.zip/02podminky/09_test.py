text = input("Zadej jakýkoli text: \n")
w = int(input("Kolikrát mám za text napsat W? \n"))
print(text, (" W ") * w)

# Zadání: Napiste program, který jako vstup vezme jakýkoli textový řetězec. Poté vás požádá,
# abyste zadali kolikrát za text napíše znak W s mezerami.
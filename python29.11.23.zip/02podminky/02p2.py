cislo = int(input("Zadej nějaké číslo: "))
if (cislo > 5):
    print("Správně, zadal jsi číslo větší než 5!")
print("Děkuji za zadání")
cislo = int(input("Zadej cele kladne cislo: "))

if (cislo >= 3): # vždy musí být : za if nebo else!!!
    print("dobře")

else:
    print("špatně")


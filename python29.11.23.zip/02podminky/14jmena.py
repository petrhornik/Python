jmeno = str(input("Zadej jméno svého spolužáka začínající na T či M: "))


if(jmeno == "Tomáš"):
    print("Ahoj " + jmeno + "i!")
elif(jmeno == "Marek"):
    print("Ahoj " + jmeno + "u!")
else:
    print("Zadán neplatný vstup!")
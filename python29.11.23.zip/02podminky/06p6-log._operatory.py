# Logické operátory
# A zárověn     and
# Nebo           or
# Negace        not

cislo = int(input("Zadej číslo v rozmezí 10-20: "))
if ((cislo >=10) and (cislo <= 20)):
    print("Zadal jsi správně!")
else:
    print("Zadal jsi špatně!")


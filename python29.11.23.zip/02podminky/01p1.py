# podmínky zapisujeme pomocí klíčového slova if

if 15 > 5:
    print("Pravda") # odsazení 4 mezery (nebo TAB)
print("program zde pokračuje dál")

# Pokud podmínka platí, provede příkaz vypisující
# do konzole text pravda. V obou případech
# program pokračuje dál
# Součástí výrazu somozřejmě může být 1 proměnná
